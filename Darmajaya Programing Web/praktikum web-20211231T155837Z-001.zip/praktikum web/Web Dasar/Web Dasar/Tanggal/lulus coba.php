 <?php
$nilai=59;
if($nilai>=60)
echo "maka lulus";
elseif($nilai<=60)
echo "maka tidak lulus";
?>