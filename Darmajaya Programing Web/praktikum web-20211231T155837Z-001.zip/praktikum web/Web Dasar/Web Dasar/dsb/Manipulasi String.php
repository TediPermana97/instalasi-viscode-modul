<?php
$i="Universitas Narotama";
$jmlhuruf=strlen($i);
echo $i."<br>";
echo "Jumlah Karakter pada 
          Kalimat diatas:".$jmlhuruf;
?>
