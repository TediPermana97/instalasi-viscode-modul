<form method ="POST "  action = "<?php $_SERVER[‘’PHP_SELP];  ?>”>
<table>
<tr>
<td>NPM</td>
<td>:</td>
<td><input type ="text" name ="npm" size = "10" max ="10" ></td>
</tr>
<tr>
<td>nama</td>
<td>:</td>
<td><input type ="text" name ="nama" size = "10" max ="10" ></td>
</tr>
<tr>
<td> </td>
<td> <input type = "submit" name ="button"> </td>
<td> <input type = "reset" name ="reset">  </td>
</tr>
</table>
</form>
