<form name="form1" method="post" action="">
  <table width="249" border="1">
    <tr>
      <th width="137" scope="row">NPM</th>
      <td width="33">:</td>
      <td width="57"><label for="textfield"></label>
      <input type="text" name="textfield" id="textfield"></td>
    </tr>
    <tr>
      <th scope="row">NAMA</th>
      <td>:</td>
      <td><label for="textfield2"></label>
      <input type="text" name="textfield2" id="textfield2"></td>
    </tr>
    <tr>
      <th scope="row">&nbsp;</th>
      <td><input type="submit" name="button" id="button" value="Submit"></td>
      <td><input type="submit" name="button2" id="button2" value="Submit"></td>
    </tr>
  </table>
</form>
