<?php
//koneksi.php
$host="localhost";
$user="root";
$pwd="";
$db="dbsiak";

mysql_connect($host,$user,$pwd);
mysql_select_db($db)

?>