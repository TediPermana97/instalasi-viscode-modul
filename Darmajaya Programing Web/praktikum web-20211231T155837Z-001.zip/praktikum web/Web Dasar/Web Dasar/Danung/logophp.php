<html>
	<head>
		<title>Latihan-02</title>
	</head>
<body>
	<?php
	phpinfo();
	Echo"NPM: 1511010027";
	Echo"NAMA: DANUNG SETYA BUDI";
	?>
</body>
</html>
