<?php
$a =3;
$b =5;
$c =$a + $b;
echo "$a+$b : $c"
?>