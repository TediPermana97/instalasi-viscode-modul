<?php
$a1 = "BE BOLD";
$a2 = "BE VIBRAINT";
$a3 = "BE A TECTNOPRENEUR";
$a4 = "BE 181 DJ";
echo "$a1 + $a2 + $a4"
?>