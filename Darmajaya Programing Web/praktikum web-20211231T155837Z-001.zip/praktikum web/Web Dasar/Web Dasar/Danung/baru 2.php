<?php
$a =3;
$b =5;
$c =$a + $b;
$d =$a * $b;
$e =$a - $b;
echo "$a+$b : $c <br> $a*$b : $d <br> $a-$b : $e"
?>