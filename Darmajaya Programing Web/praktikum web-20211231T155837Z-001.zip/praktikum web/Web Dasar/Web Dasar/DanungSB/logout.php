<?php
setcookie("nama","");
header("Location: index.php?logout=success");
?>