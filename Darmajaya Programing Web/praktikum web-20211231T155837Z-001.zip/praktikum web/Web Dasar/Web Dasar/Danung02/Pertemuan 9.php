<?php
$a=5;
Echo "\$a bernilai $a <br>";

Switch ($a)
{
	case $a=10:
		echo "Berarti \$a = 10";
		break; 
	case $a>10:
		echo "Berarti \$a > 10";
		break;
	default:
		echo "Berarti \$a < 10";
}
?>
