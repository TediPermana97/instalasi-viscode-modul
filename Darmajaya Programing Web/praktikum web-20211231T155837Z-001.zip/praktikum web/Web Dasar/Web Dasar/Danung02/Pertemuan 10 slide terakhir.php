<?php
	function x1()
	{
		echo "Institut IBI Darmajaya <br>" ;
		echo "Bandar Lampung";
	}
	
	function x2()
	{
		echo "TI";
	}
?>