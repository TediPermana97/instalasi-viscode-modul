<?php
$nama = $_request['nama'];
$rahasia = $_request['rahasia'];

echo $nama;
echo "<br>";
echo $rahasia;
?>