<HTML>
<BODY>
	<form method=get action=PW.php method="post">
		Username: <input type=text name=nama>
		<br>
		Password: <input type=password name=rahasia>
		<br>
		<input type=submit value=login>
	</form>
</BODY>
</HTML>

