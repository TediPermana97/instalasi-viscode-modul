<?php
$a=3;
$b=5;
$c =$a + $b;
$d =$a * $b;
$e =$b -$a;
echo"$a + $b = $c";
echo "<br>";
echo"$a * $b = $d";
echo "<br>";
echo"$a - $b = $c";
?>