<?php echo "
<TABLE>
   <TR>
        <TD width=50>NIM</TD>
        <TD width=100>NAMA</TD>
   </TR>
<TR>
        <TD width=50>1511010029</TD>
        <TD width=100>Tedi permana</TD>
   </TR>
</TABLE>
"; ?>
