<HTML>
   <HEAD>
       <TITLE>Test Include</TITLE>
   </HEAD>
<BODY>
    <?php
     include "table.php";
    ?>
</BODY>
</HTML>
