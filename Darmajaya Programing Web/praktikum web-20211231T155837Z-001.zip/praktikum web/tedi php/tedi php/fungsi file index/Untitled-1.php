<?php
$angka = 10;
$cek = 1;
Echo "Bil. Genap antara 10 hingga 30: <br>";
For ($cek=1;$cek<10;$cek++)
{
	$angka += 2;
	echo "$angka <br>";
}
?>
