<?php require "fungsi.php"; ?>
<HTML>
   <HEAD>
       <TITLE>Test Require</TITLE>
   </HEAD>
<BODY>
    <?php
     x1();
    ?>
</BODY>
</HTML>
