<table width="241" border="1">
  <tr>
    <td width="60">NPM</td>
    <td width="12">:</td>
    <td width="147"><form name="form1" method="post" action="">
      <label for="textfield"></label>
      <input type="text" name="textfield" id="textfield">
    </form></td>
  </tr>
  <tr>
    <td>NAMA</td>
    <td>:</td>
    <td><form name="form2" method="post" action="">
      <label for="textfield2"></label>
      <input type="text" name="textfield2" id="textfield2">
    </form></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><form name="form3" method="post" action="">
      <input type="submit" name="Submit" id="button" value="BERSIH">
      <input type="submit" name="button2" id="button2" value="SIMPAN">
    </form></td>
  </tr>
</table>
