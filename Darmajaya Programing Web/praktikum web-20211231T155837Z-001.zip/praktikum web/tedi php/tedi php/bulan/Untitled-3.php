<?php
$bulan=array("Januari","Februari","Maret","April");
Echo "Musim hujan biasanya terjadi pada bulan: <br> ";
//akses array
Echo "$bulan[0] <br>";
Echo "$bulan[1] <br>";
Echo "$bulan[2] <br>";
?>
