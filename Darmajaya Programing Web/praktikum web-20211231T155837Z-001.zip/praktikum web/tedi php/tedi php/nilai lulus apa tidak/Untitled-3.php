 <?php
$nilai=59;
if($nilai>=60)
echo "maka lulus";
else if($nilai>=60)
echo "tidak lulus";
?>
