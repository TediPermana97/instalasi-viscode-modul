<?php
$a=10;
Echo "\$a bernilai $a <br>";

Switch ($a)
{
	case $a=5:
		echo "Berarti \$a = 5";
		break; 
	case $a>5:
		echo "Berarti \$a > 5";
		break;
	default:
		echo "Berarti \$a < 5";
}
?>



