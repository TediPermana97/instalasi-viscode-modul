<HTML>
<BODY>
	<form method=post action=php.php>
		input nilai a: <input type=text name=nama>
		<br>
		input nilai b: <input type=password name=rahasia>
		<br>
		<input type=submit value=login>
	</form>
</BODY>
</HTML>
