<?php
$a=$_REQUEST["a"];
$b=$_REQUEST["b"];