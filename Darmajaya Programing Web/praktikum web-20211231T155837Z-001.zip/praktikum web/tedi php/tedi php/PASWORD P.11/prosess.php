<HTML>
<BODY>
	<form method=post action=php.php>
		Username: <input type=text name=nama>
		<br>
		Password: <input type=password name=rahasia>
		<br>
		<input type=submit value=login>
	</form>
</BODY>
</HTML>
