<?php
$nama=$_REQUEST['nama'];
$rahasia=$_REQUEST['rahasia'];

echo $nama;
echo "<br>";
echo $rahasia;
?>
