<?php
     phpinfo();
	 echo"NPM: 1511010029";
	 echo"NAMA: tedipermana";
	
?>