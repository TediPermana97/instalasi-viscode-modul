<?php 
    function x1()
    {
       echo "Universitas Narotama <br>";
       echo "Surabaya";
    }
    
    function x2()
    {
      echo "FASILKOM";
    }
?>
