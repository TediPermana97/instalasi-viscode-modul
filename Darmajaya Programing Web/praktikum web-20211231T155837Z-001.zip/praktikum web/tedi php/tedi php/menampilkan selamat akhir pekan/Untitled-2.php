<html>
<body>
 <?php
$d=date("D");
if($d=="Fri")echo"have a nice weekend!";
else
echo "Have nice day";
elseif ($d=="Sun")
echo "Have a nice Sunday!";
else
echo "Have a nice day!";
?>
</body>
</body>