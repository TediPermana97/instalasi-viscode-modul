<html>
<body>
 <?php
$nilai=60;
if($ni>=60)
echo "nilai 60";
else
echo "tidak lulus";
?>
</body>
</body>