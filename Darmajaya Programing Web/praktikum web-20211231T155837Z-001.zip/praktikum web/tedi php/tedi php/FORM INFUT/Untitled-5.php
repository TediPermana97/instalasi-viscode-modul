<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="233" border="0">
    <tr>
      <td width="72">NPM</td>
      <td width="10">:</td>
      <td width="144"><label for="NPM"></label>
      <input type="text" name="NPM" id="NPM" /></td>
    </tr>
    <tr>
      <td>NAMA</td>
      <td>:</td>
      <td><label for="NAMA"></label>
      <input type="text" name="NAMA" id="NAMA" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><input type="reset" name="Reset" id="button" value="BERSIH" />
      <input type="submit" name="button2" id="button2" value="SIMPAN" /></td>
    </tr>
  </table>
</form>
</body>
</html>